# flickR
SQL File Loading package built in R
